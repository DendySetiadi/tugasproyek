<?php $__env->startSection('title','Daftar Mobil | Mekanik'); ?>
<?php $__env->startSection('judul','Data Mobil Aotlie Service'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <br><a href="<?php echo e(asset('mekanik')); ?> " class="btn btn-warning">Kembali ke daftar Mobil</a><br><br>
            <table>
                <form action="" method="post" enctype="multipart/form-data" class="row">
                    <div class="mb-3">
                        <label for="Jenis" class="form-label"><strong>Jenis</strong></label><br>
                        <p><?php echo e($mobil->Jenis); ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="Merek" class="form-label"><strong>Merek</strong></label>
                        <p><?php echo e($mobil->Merek); ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="Plat_Nomor" class="form-label"><strong>Plat Nomor Kendaraan</strong> </label>
                        <p><?php echo e($mobil->Plat_Nomor); ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="Pemilik" class="form-label"><strong>Pemilik Kendaraan</strong> </label>
                        <p><?php echo e($mobil->Pemilik); ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="stnk" class="form-label"><strong>No. STNK</strong> </label>
                        <p ><?php echo e($mobil->stnk); ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="keluhan" class="form-label"><strong>Masalah dalam Mobil</strong> </label>
                        <p class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="content" rows="5" placeholder="Masukkan Konten Blog"><?php echo e($mobil->keluhan); ?></p>
                    </div>
                </form>
            </table>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tenp.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\proyekpsw-laravel\proyekpsw-laravel\resources\views/mekanik/show.blade.php ENDPATH**/ ?>