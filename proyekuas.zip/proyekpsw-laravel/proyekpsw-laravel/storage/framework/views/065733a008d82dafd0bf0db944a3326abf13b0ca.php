<?php $__env->startSection('title', 'Data Customer | Admin'); ?>
<?php $__env->startSection('judul', 'Isi Data Dibawah Ini Dengan Benar !'); ?>
<?php $__env->startSection('content'); ?>
    <div class="containerr mt-4">
            <form action="<?php echo e(route('customer.update',$customer->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
			<div class="mb-3">
                <label for="ID_customer" class="form-label">ID_Customer</label>
                <p><?php echo e($customer->ID_customer); ?></p>
            </div>
            <div class="mb-3">
               <label for="Nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="Nama"  name="Nama" value="<?php echo e(old('Nama', $customer->Nama)); ?>">
            </div>
            <div class="mb-3">
                <label for="Alamat" class="form-label">Alamat</label>
                <input type="text" class="form-control" id="Alamat"  name="Alamat" value="<?php echo e(old('Alamat', $customer->Alamat)); ?>">
            </div>
            <div class="mb-3">
                <label for="NoTelp" class="form-label">No Handphone</label>
                <input type="text" class="form-control" id="NoTelp" name="NoTelp" value="<?php echo e(old('NoTelp', $customer->NoTelp)); ?>">
            </div><br>
            <div class="text-center">
                <button class="btn btn-danger text-white" type="reset">Reset</button>
                <button class="btn btn-info text-white" type="submit" name="submit">Edit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\proyekpsw-laravel\proyekpsw-laravel\resources\views/customer/edit.blade.php ENDPATH**/ ?>