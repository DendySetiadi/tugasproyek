<?php $__env->startSection('title', 'Kontak '); ?>

<!--Navbar-->
<?php $__env->startSection('navbar'); ?>
    <header>
      <nav class="navbar navbar-expand-lg navbar-inverse navbar-light">
        <div class="container">
          <a class="navbar-brand" href="<?php echo e(asset('/')); ?> ">
            <h1><img src="css/Image/logo.jpeg" class="rounded-circle" style="width: 45px" alt="" /> BERKAH Service</h1>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo e(asset('/about')); ?> ">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(asset('/service')); ?>">Service</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(asset('/registrasi')); ?>">Registration</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(asset('/kontak')); ?> ">Contact Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-item btn btn-primary tombol" href="<?php echo e(asset('login')); ?>">Login</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <br />
<?php $__env->stopSection(); ?>
<!--Akhir Navbar-->

<?php $__env->startSection('content'); ?>
    <h1><b style="margin-left: 160px; color: black">CONTACT US</b></h1>
    <!--informasi -->
    <div class="row justify-content-center">
      <div class="col-md-3 col-lg-3 info-panel2">
        <div class="row text-center">
          <h4>Telepon</h4>
          <i class="bi bi-telephone" style="font-size: 80px"></i>
          <p>+62 892 2121 9088</p>
          <p>+62 880 7766 2121</p>
        </div>
      </div>
      <div class="col-md-3 col-lg-3 info-panel2">
        <div class="row text-center">
          <h3>Alamat</h3>
          <i class="bi bi-geo-alt-fill" style="font-size: 80px"></i>
          <p><br />Jalan Damai</p>
        </div>
      </div>
      <div class="col-md-3 col-lg-3 info-panel2">
        <div class="row text-center">
          <h3>Email</h3>
          <i class="bi bi-envelope" style="font-size: 80px"></i>
          <p><br />Berkah Service@gmail.com</p>
        </div>
      </div>
    </div>
    <br /><br /><br /><br />
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('map'); ?>
        <div class="container">
      <iframe
      >
      </iframe>
    </div>
    <br /><br />
    <?php $__env->stopSection(); ?>
    

    <!--akhir Informasi-->

    
<?php echo $__env->make('layouts.defaultone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\proyekpsw-laravel\proyekpsw-laravel\resources\views/kontak/index.blade.php ENDPATH**/ ?>