<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" href="<?php echo e(asset('css/Image/logo.jpeg')); ?> " />
    <title>Registration | BERKAH</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!--Style CSS-->
    <link rel="stylesheet" href="css/style.css" />
    <!--Style Icons-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <a href="https://icons8.com/icon/he8U4VPWGpWe/"></a>
  </head>
  <body>
    <!--Navbar-->
    <header>
      <nav class="navbar navbar-expand-lg navbar-inverse navbar-light">
        <div class="container">
          <a class="navbar-brand" href="<?php echo e(asset('/')); ?> ">
            <h1><img src="css/Image/logo.jpeg" class="rounded-circle" style="width: 45px" alt="" />BERKAH Service</h1>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo e(url('/about')); ?>">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/service')); ?>">Service</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/mobil">Mobil</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/motor">Motor</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/sepeda">Sepeda</a>
              </li>
              <li class="nav-item">
                 <?php if(Route::has('login')): ?>
                <div class="hidden fixed sm:block">
                  <?php if(auth()->guard()->check()): ?>
                      <a class="nav-item btn btn-danger tombol" href="<?php echo e(route('logout')); ?>">Log Out</a>
                  <?php else: ?>
                      <a class="nav-item btn btn-primary tombol" href="<?php echo e(asset('login')); ?>">Login</a>
                  <?php endif; ?>
                </div>
                <?php endif; ?>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <br />
    <div class="container judul">
      <h2>&nbsp;Booking Service</h2>
      <h5 class="mb-2">Note: Untuk melakukan registrasi, customer login terlebih dahulu.</h5>
    </div>
    <div class="container">
      
      <section class="regis ">        
        <div class="row" >
          <div class="col-md-5" >
            <h3>Personal Information</h3>
              <form action="/booking" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                  </div>  
                <?php endif; ?>
                <div>
                  <label for="Nama" class="form-label">Nama</label>
                  <input type="text" class="form-control" id="Nama" name="Nama" />
                  <?php $__errorArgs = ['Nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                <div>
                  <label for="Alamat" class="form-label">Alamat</label>
                  <input type="text" class="form-control" id="Alamat" name="Alamat" />
                  <?php $__errorArgs = ['Alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                <div>
                  <label for="NoTelp" class="form-label">No. Telepon</label>
                  <input type="text" class="form-control" id="NoTelp" name="NoTelp" />
                  <p>Nb: *Anda harus mengisi No. Telepon, agar dapat di hubungi oleh Admin. </p>
                  <?php $__errorArgs = ['NoTelp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                </div>
          
                  <div class="col-md-5" >
                    <h3>Booking Information</h3>
                  <div>
                      <div>
                  <label for="Jenis" class="form-label">Jenis Mobil</label>
                  <input type="text" class="form-control" id="Jenis" name="Jenis" />
                  <?php $__errorArgs = ['Jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                  <label for="Merek" class="form-label">Merek</label>
                  <input type="text" class="form-control" id="Merek" name="Merek" />
                  <?php $__errorArgs = ['Merek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                  <label for="Plat_Nomor" class="form-label">Plat Nomor</label>
                  <input type="text" class="form-control" id="Plat_Nomor" name="Plat_Nomor" />
                  <?php $__errorArgs = ['Plat_Nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                  <label for="Pemilik" class="form-label">Pemilik Kendaraan</label>
                  <input type="text" class="form-control" id="Pemilik" name="Pemilik" />
                  <?php $__errorArgs = ['Pemilik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                  <label for="stnk" class="form-label">Nomor STNK</label>
                  <input type="text" class="form-control" id="stnk" name="stnk" />
                  <?php $__errorArgs = ['stnk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                  <label for="keluhan" class="form-label">Masalah pada Mobil</label><br>
                  <textarea class="form-control <?php $__errorArgs = ['keluhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> deskripsi" name="keluhan" rows="10" ><?php echo e(old('keluhan')); ?></textarea>
                  <?php $__errorArgs = ['keluhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1">
                        <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br />
                <button type="reset" class="submit btn btn-light submit" name="submit" style="margin-right: 40px;">RESET</button>
                <?php if(Route::has('login')): ?>
                <div class="hidden fixed sm:block">
                  <?php if(auth()->guard()->check()): ?>
                      <button type="submit" class="submit btn btn-primary submit" name="submit" style="margin-right: 40px">SUBMIT</button>
                      
                  <?php else: ?>
                      <button onClick="alert('Anda harus login terlebih dahulu!')" class="submit btn btn-primary submit"  style="margin-right: 40px">SUBMIT</button>
                  <?php endif; ?>
                </div>
                <?php endif; ?>
                
              </form>
            </div>
          </div>
        </div>
      </section>
      </div>

    
  </body>
</html>
<?php /**PATH C:\Users\LENOVO\Downloads\proyekpsw-laravel\proyekpsw-laravel\resources\views/registrasi/registration.blade.php ENDPATH**/ ?>