<?php $__env->startSection('title','Daftar Customer | Admin'); ?>
<?php $__env->startSection('judul','Data  Customer Berkah Service'); ?>
<?php $__env->startSection('content'); ?>
     <div class="containerr mt-1">
		<a href="<?php echo e(route('customer.create')); ?>" class="btn btn-outline-info">+ Customer Baru</a>
        <div class="row">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Customer</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No Telepon</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?> </td>
                        <td><?php echo e($customer->ID_customer); ?> </td>
                        <td><?php echo e($customer->Nama); ?> </td>
                        <td><?php echo e($customer->Alamat); ?> </td>
                        <td><?php echo e($customer->NoTelp); ?> </td>
                        <td>
                        <form action="<?php echo e(route('customer.show',$customer->id)); ?>" method="POST" >
                        <a class="btn btn-primary" href="<?php echo e(route('customer.edit',$customer->id)); ?> ">Edit</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <div class="d-flex justify-content-end">
        <?php echo e($customers->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\proyekpsw-laravel\proyekpsw-laravel\resources\views/customer/index.blade.php ENDPATH**/ ?>