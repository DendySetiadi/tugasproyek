<?php $__env->startSection('title', 'Daftar Mobil | Mekanik'); ?>
<?php $__env->startSection('judul', 'Data  Mobil Aotlie Service'); ?>
<?php $__env->startSection('content'); ?>
     <div class="containerr mt-1">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID Mobil</th>
                    <th>Jenis</th>
                    <th>Merek</th>
                    <th>Plat Mobil</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e(++$i); ?> </td>
					<td><?php echo e($mobil->ID_Registrasi); ?> </td>
					<td><?php echo e($mobil->Jenis); ?> </td>
					<td><?php echo e($mobil->Merek); ?> </td>
					<td><?php echo e($mobil->Plat_Nomor); ?> </td>
					<td>
					<form action="<?php echo e(route('mekanik.show',$mobil->id)); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
					<a class="btn btn-info btn-sm" href="<?php echo e(route('mekanik.show',$mobil->id)); ?>">Show</a>	   
                </form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
    <div class="d-flex justify-content-end">
        <?php echo e($mobils->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('tenp.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\proyekpsw-laravel\proyekpsw-laravel\resources\views/mekanik/index.blade.php ENDPATH**/ ?>