<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\MekanikController;
use App\Http\Controllers\PelangganController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\MobilController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\MotorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/motor', [MotorController::class, 'index'])->name('motor.index');
Route::get('/motor/create', [MotorController::class, 'create'])->name('motor.create');
Route::post('/motor', [MotorController::class, 'store'])->name('motor.store');
Route::get('/motor/{mobil}', [MotorController::class, 'show'])->name('motor.show');
Route::get('/motor/{mobil}/edit', [MotorController::class, 'edit'])->name('motor.edit');
Route::put('/motor/{mobil}', [MotorController::class, 'update'])->name('motor.update');
Route::delete('/motor/{mobil}', [MotorController::class, 'destroy'])->name('motor.destroy');


Route::get('/about', [AboutController::class,'tentang']);
Route::get('/kontak', [AboutController::class, 'kontak']);
Route::get('/service', [ServiceController::class, 'service']);

Route::get('/mobil', [BookingController::class, 'index'])->name('registrasi');
Route::get('/motor', [BookingController::class, 'motor'])->name('registrasi');
Route::get('/sepeda', [BookingController::class, 'sepeda'])->name('registrasi');

Route::get('/registrasi', [BookingController::class, 'index'])->name('registrasi');

Route::get('login', 'App\Http\Controllers\AuthController@index')->name('login');
Route::get('register', 'App\Http\Controllers\AuthController@register')->name('register');
Route::post('simpanregister', 'App\Http\Controllers\AuthController@simpanregister')->name('simpanregister');
Route::post('proses_login', 'App\Http\Controllers\AuthController@proses_login')->name('proses_login');
Route::get('logout', 'App\Http\Controllers\AuthController@logout')->name('logout');

Route::group(['middleware' => ['auth']], function () {
    Route::group(['middleware' => ['cek_login:admin']], function () {
        Route::resource('admin/customer', CustomerController::class);
        Route::resource('admin/mobil', MobilController::class);
    });
    Route::group(['middleware' => ['cek_login:pelanggan']], function () {
        Route::resource('pelanggan', PelangganController::class);
        Route::post('/booking', [BookingController::class, 'store'])->name('registrasi');
        Route::post('/bookingmotor', [BookingController::class, 'storemotor'])->name('registrasi');

        Route::post('/bookingsepeda', [BookingController::class, 'storesepeda'])->name('registrasi');

    });
    Route::group(['middleware' => ['cek_login:mekanik']], function () {
        Route::resource('mekanik', MekanikController::class);
        
    });
});

