<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Sepeda extends Model
{
    use HasFactory;

    protected $fillable = [
        'ID_Registrasi', 'Jenis', 'Merek',  'Pemilik', 'keluhan'   
    ];

     public static function getId()
    {
        return $getId = DB::table('sepeda')->orderBy('id','DESC')->take(1)->get();
    }
}