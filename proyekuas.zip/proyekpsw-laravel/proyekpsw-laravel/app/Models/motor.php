<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Motor extends Model
{
    use HasFactory;
    protected $table = "motor";
    protected $primaryKey = "id";
    protected $fillable = ['ID_Registrasi', 'Jenis', 'Merek', 'Plat_Nomor', 'Pemilik', 'stnk', 'keluhan'];

    public static function getId()
    {
        return self::orderBy('id', 'desc')->first();
    }
}
