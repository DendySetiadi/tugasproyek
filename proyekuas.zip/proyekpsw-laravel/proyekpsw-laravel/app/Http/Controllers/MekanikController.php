<?php

namespace App\Http\Controllers;

use App\Models\Mobil;
use App\models\Motor;
use Illuminate\Http\Request;

class MekanikController extends Controller
{

    public function index()
    {
        $mobils = Mobil::latest()->simplePaginate(5);
                                                        
        return view('mekanik.index',compact('mobils'))
            ->with('i',(request()->input('page',1) - 1) * 5);
    }

    public function showMobil($id)
    {
        $mobil = Mobil::find($id);
        return view('mekanik.show', compact('mobil'));
    }
    
    public function showMotor($id)
    {
        $motor = Motor::find($id);
        return view('mekanik.show', compact('motor'));
    }
    

  
}
