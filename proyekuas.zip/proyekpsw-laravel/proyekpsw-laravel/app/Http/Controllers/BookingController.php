<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Mobil;
use App\Models\motor;
use App\Models\Sepeda;
class BookingController extends Controller
{
    public function index()
    {
        return view('registrasi.registration');
    }
    public function motor()
    {
        return view('registrasi.motor');
    }
    public function sepeda()
    {
        return view('registrasi.sepeda');
    }

    
    public function storemotor(Request $request)
    {
        $this->validate($request,[
            'Nama'   => 'required',
            'Alamat' => 'required',
            'NoTelp' => 'required'
        ]);
        Customer::create([
            'Nama'   => $request->Nama,
            'Alamat' => $request->Alamat,
            'NoTelp' =>$request->NoTelp
        ]);

        $this->validate($request,[
            'Jenis'      => 'required',
            'Merek'      => 'required',
            'Plat_Nomor' => 'required',
            'Pemilik'    => 'required',
            'stnk'       => 'required',
            'keluhan'    => 'required'
        ]);
        motor::create([
            'Jenis'      => $request->Jenis,
            'Merek'      => $request->Merek,
            'Plat_Nomor' => $request->Plat_Nomor,
            'Pemilik'    => $request->Pemilik,
            'stnk'       => $request->stnk,
            'keluhan'    => $request->keluhan
        ]);
    }

public function store(Request $request)
    {
        $data = $request->all();
        $id = Customer::getId(); $idlm = 0; // Inisialisasi variabel $idlm sebelum loop foreach
        $idlm = 0; // Inisialisasi variabel $idlm sebelum loop foreach
        $value = null; // Inisialisasi variabel $value sebelum digunakan
        foreach ($id as $value) {
            $idlm = $value->id;
        }
        $idbaru = $idlm + 1;
        $blt = date('d-m-y');

        $no_pengembalian = 'SVC/'.$blt.'/'.$idbaru;

        $this->validate($request, [
            'Nama'   => 'required',
            'Alamat' => 'required',
            'NoTelp' => 'required'
        ]);

        $customer = new Customer;
        $customer->ID_customer = $no_pengembalian; 
        $customer->Nama = $data['Nama'];
        $customer->Alamat = $data['Alamat'];
        $customer->NoTelp = $data['NoTelp'];
        $customer->save();

        $id = Mobil::getId();
        $value = null; // Inisialisasi variabel $value sebelum digunakan
       
        foreach ($id as $value) {

        $idlm = $value->id;

        }

        $idbaru = $idlm + 1;
        $blt = date('d-m-y');

        $no_pengembalian_mobil = 'MBL/'.$blt.'/'.$idbaru;

        $this->validate($request, [
            'Jenis'      => 'required',
            'Merek'      => 'required',
            'Plat_Nomor' => 'required',
            'Pemilik'    => 'required',
            'stnk'       => 'required',
            'keluhan'    => 'required'
        ]);

        $mobil = new Mobil;
        $mobil->ID_Registrasi = $no_pengembalian_mobil;
        $mobil->Jenis = $data['Jenis'];
        $mobil->Merek = $data['Merek'];
        $mobil->Plat_Nomor = $data['Plat_Nomor'];
        $mobil->Pemilik = $data['Pemilik'];
        $mobil->stnk = $data['stnk'];
        $mobil->keluhan = $data['keluhan'];
        $mobil->save();

        return redirect()->back()->with('status', 'Data Berhasil Dimasukkan');
    }


    
}
